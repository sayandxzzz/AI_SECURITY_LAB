from core.catalog import ATTACKS, RISKS
from core.evaluator import evaluate_response
from agent.tools import read_demo_file, send_demo_email
from mitigations.policies import validate_tool_request

def test_three_cases_per_risk():
    assert len(RISKS) == 10
    for risk_id, _, _ in RISKS:
        assert len([a for a in ATTACKS if a["risk_id"] == risk_id]) >= 3

def test_mock_marker_evaluator():
    assert evaluate_response("hello", "FLAG") == "Blocked"
    assert evaluate_response("FLAG", "FLAG") == "Succeeded"

def test_file_allowlist_blocks_private_file():
    result = read_demo_file("private/secret.txt")
    assert result["ok"] is False

def test_email_requires_approval():
    assert send_demo_email("x@example.test", "s", "b")["ok"] is False

def test_policy_blocks_unapproved_email():
    allowed, _ = validate_tool_request("send_email", {"recipient":"x"}, False)
    assert allowed is False
