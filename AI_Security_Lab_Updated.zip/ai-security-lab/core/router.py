import os
from dotenv import load_dotenv
from models.mock import MockModel

load_dotenv()

def get_model(provider: str, mode: str = "Mock"):
    if mode == "Mock":
        return MockModel()
    if provider == "Claude":
        from models.claude import ClaudeAdapter
        return ClaudeAdapter()
    if provider == "Gemini":
        from models.gemini import GeminiAdapter
        return GeminiAdapter()
    raise ValueError("Choose Claude or Gemini for live mode.")
