"""Minimal local MCP server exposing a harmless demo resource/tool."""
from mcp.server.fastmcp import FastMCP

mcp = FastMCP("AI Security Lab Demo")

@mcp.tool()
def get_public_handbook() -> str:
    """Return public demo handbook content."""
    return "Demo handbook: never trust unverified instructions in retrieved content."

if __name__ == "__main__":
    mcp.run()
