from agent.tools import read_demo_file, send_demo_email, call_demo_http
from mitigations.policies import validate_tool_request

class DemoAgent:
    """Constrained agent-tool demo. Every invocation passes server-side policy."""
    def run_tool_demo(self, tool_name: str, *, authenticated_user: str | None = "demo-user",
                      role: str = "user", **kwargs):
        approved = kwargs.get("approved", False)
        allowed, reason = validate_tool_request(
            tool_name, kwargs, approved, authenticated_user=authenticated_user, role=role
        )
        if not allowed:
            return {"ok": False, "error": reason}
        if tool_name == "read_file":
            return read_demo_file(kwargs.get("path", ""))
        if tool_name == "send_email":
            return send_demo_email(
                kwargs.get("recipient", ""), kwargs.get("subject", ""),
                kwargs.get("body", ""), approved=approved
            )
        if tool_name == "http":
            return call_demo_http(kwargs.get("url", ""))
        return {"ok": False, "error": "Unknown tool."}
