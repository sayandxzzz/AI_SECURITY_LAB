from typing import Protocol, Optional, Any

class ModelAdapter(Protocol):
    name: str
    def generate(self, prompt: str, system_prompt: Optional[str] = None,
                 max_tokens: int = 1024) -> dict[str, Any]: ...
