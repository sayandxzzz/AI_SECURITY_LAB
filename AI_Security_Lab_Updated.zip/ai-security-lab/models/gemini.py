import os
from typing import Optional
from dotenv import load_dotenv
from mitigations.policies import bound_prompt
from google import genai

load_dotenv()

class GeminiAdapter:
    name = "Gemini"
    def __init__(self):
        key = os.getenv("GEMINI_API_KEY")
        if not key:
            raise ValueError("GEMINI_API_KEY is missing. Add it to .env.")
        self.model = os.getenv("GEMINI_MODEL", "gemini-2.5-flash")
        self.client = genai.Client(api_key=key)

    def generate(self, prompt: str, system_prompt: Optional[str] = None,
                 max_tokens: int = 1024) -> dict:
        prompt = bound_prompt(prompt)
        if not isinstance(max_tokens, int) or not 1 <= max_tokens <= 8192:
            raise ValueError("max_tokens must be an integer between 1 and 8192.")
        try:
            config = {"max_output_tokens": max_tokens}
            if system_prompt:
                config["system_instruction"] = system_prompt
            response = self.client.models.generate_content(
                model=self.model, contents=prompt, config=config
            )
            usage = getattr(response, "usage_metadata", None)
            return {
                "success": True, "model": self.model,
                "response": response.text or "",
                "input_tokens": getattr(usage, "prompt_token_count", 0) or 0,
                "output_tokens": getattr(usage, "candidates_token_count", 0) or 0,
                "stop_reason": "completed", "execution_mode": "LIVE"
            }
        except Exception as exc:
            return {"success": False, "model": self.model,
                    "error": f"{type(exc).__name__}: {exc}",
                    "response": None, "execution_mode": "LIVE"}
