import os
from typing import Optional
from dotenv import load_dotenv
from mitigations.policies import bound_prompt
from anthropic import Anthropic

load_dotenv()

class ClaudeAdapter:
    name = "Claude"
    def __init__(self):
        key = os.getenv("ANTHROPIC_API_KEY")
        if not key:
            raise ValueError("ANTHROPIC_API_KEY is missing. Add it to .env.")
        self.model = os.getenv("CLAUDE_MODEL", "claude-sonnet-4-5")
        self.client = Anthropic(api_key=key, timeout=45.0, max_retries=2)

    def generate(self, prompt: str, system_prompt: Optional[str] = None,
                 max_tokens: int = 1024) -> dict:
        prompt = bound_prompt(prompt)
        if not isinstance(max_tokens, int) or not 1 <= max_tokens <= 8192:
            raise ValueError("max_tokens must be an integer between 1 and 8192.")
        request = {"model": self.model, "max_tokens": max_tokens,
                   "messages": [{"role": "user", "content": prompt}]}
        if system_prompt:
            request["system"] = system_prompt
        try:
            response = self.client.messages.create(**request)
            output = "\n".join(
                block.text for block in response.content
                if getattr(block, "type", None) == "text"
            )
            return {
                "success": True, "model": self.model, "response": output,
                "input_tokens": response.usage.input_tokens,
                "output_tokens": response.usage.output_tokens,
                "stop_reason": response.stop_reason,
                "request_id": getattr(response, "_request_id", None),
                "execution_mode": "LIVE"
            }
        except Exception as exc:
            # Do not log prompt contents or API credentials.
            return {"success": False, "model": self.model,
                    "error": f"{type(exc).__name__}: {exc}",
                    "response": None, "execution_mode": "LIVE"}
