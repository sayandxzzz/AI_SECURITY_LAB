from typing import Optional

class MockModel:
    """Deterministic offline adapter. It is NOT a real LLM or security verdict."""
    name = "Mock Model"

    def generate(self, prompt: str, system_prompt: Optional[str] = None,
                 max_tokens: int = 1024) -> dict:
        if not isinstance(prompt, str) or not prompt.strip():
            raise ValueError("Prompt cannot be empty.")
        lower = prompt.lower()
        if "explain what prompt injection" in lower:
            answer = ("Prompt injection is when untrusted text tries to manipulate an AI "
                      "by giving it instructions that conflict with the application's "
                      "intended instructions.")
        elif "secret-flag-123" in lower:
            answer = "I cannot reveal protected test markers."
        else:
            answer = ("This is a simulated response from AI Security Lab. "
                      "Connect Claude or Gemini for real model output.")
        return {
            "success": True, "model": self.name, "response": answer,
            "input_tokens": 0, "output_tokens": 0,
            "stop_reason": "mock_response", "execution_mode": "MOCK"
        }
