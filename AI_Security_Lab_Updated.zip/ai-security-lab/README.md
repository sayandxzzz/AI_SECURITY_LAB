# AI Security Lab

A local proof-of-concept for evaluating selected OWASP LLM and Agentic AI risks against a demo application.

## Important scope and honesty notes

- Mock mode is simulated. It is useful for developing the interface but is NOT a Claude/Gemini security result.
- Live mode requires your own API keys and may incur provider charges.
- Use only synthetic data and test only this application.
- The marker-based evaluator is intentionally simple. It does not prove a model is secure; manual review and stronger risk-specific assertions are needed.
- Agent tools are local simulations. No email is sent, no external HTTP request is made, and no arbitrary code is executed.
- The MCP POC exposes one harmless local tool.

## Requirements

- Python 3.10+
- Windows, macOS, or Linux
- API keys only if you want live Claude/Gemini tests

## Windows quick start

1. Extract the ZIP.
2. Open the extracted `ai-security-lab` folder in VS Code.
3. Open Terminal > New Terminal.
4. Run:

```powershell
python -m venv venv
.\venv\Scripts\Activate.ps1
pip install -r requirements.txt
copy .env.example .env
streamlit run main.py
```

If PowerShell blocks activation, run:

```powershell
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
.\venv\Scripts\Activate.ps1
```

The dashboard runs in mock mode without API keys.

## Enable Claude

1. Create an API key at https://console.anthropic.com/
2. Open `.env` and set `ANTHROPIC_API_KEY=...`
3. In the dashboard select provider `Claude` and execution mode `Live`.

## Enable Gemini

1. Create an API key at https://aistudio.google.com/
2. Open `.env` and set `GEMINI_API_KEY=...`
3. In the dashboard select provider `Gemini` and execution mode `Live`.

Never commit `.env` or share API keys. If a key was included in a ZIP or screenshot, revoke it and create a replacement.

## Run tests

```powershell
pytest -q
```

## MCP POC

From the project root:

```powershell
python mcp_lab/server.py
```

This starts the local MCP server using stdio. It is intended for local inspection and extension.

## What is included

- Claude and Gemini adapters with a shared `generate()` interface
- Offline mock adapter
- Streamlit dashboard
- 10 requested risk categories and 30 harmless test prompts
- Basic marker-based result classification and CSV export
- Constrained fake agent tools and server-side allowlist/approval checks
- Minimal local MCP server
- Starter pytest suite

## What remains before final submission

This is a working starter POC, not a finished security assessment. Before submission, extend the risk-specific evaluators, run and manually review every case on both live providers, implement and measure a distinct mitigation for each risk, add a documented MCP threat scenario and mitigation comparison, inspect the results, and prepare the final report and demo video. Do not claim tests were run unless they actually were.


## Security controls added in this revision

The application now has centralized, fail-closed checks for the demo agent tools; exact file allowlisting; HTTPS destination allowlisting; explicit approval for simulated side effects; output redaction; prompt-size limits; untrusted-content delimiters; JSON unknown-field rejection; memory-write provenance/confirmation checks; and an explicit no-code-execution policy.

These are local proof-of-concept controls. They do not constitute production authentication, complete DLP, a semantic model safety guarantee, or a sandbox. See `docs/implementation_status.md` for the risk-by-risk coverage and limitations.
